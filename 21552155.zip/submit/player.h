void setUpPlayer(void);
void playerMove(char direction);
int getPlayerRow(void);
int getPlayerCol(void);
void playerExit(void);