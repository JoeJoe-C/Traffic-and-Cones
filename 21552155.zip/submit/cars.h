void setUpCars(int row, int col);
int getCarDirection(int index);
int getCarCol(int index);
int* getCarRows(void);
void carExit(void);
int getNumberOfCars(void);
int* getCar(int index);
void changeDirection(int index);