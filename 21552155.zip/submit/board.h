void setUpBoard(int row, int col);
void createEmptyBoard(int row, int col);
void displayBoard(void);
int getBoardRow(void);
int getBoardCol(void);
void boardExit(void);
char** getBoard(void);